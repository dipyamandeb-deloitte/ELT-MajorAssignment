{{ config(materialized='table') }}


SELECT code, MIN(NAV) as minimum, MAX(NAV) as maximum
FROM "MAJORASSIGNMENT"."MAJOR"."NAV_HISTORY"
GROUP BY CODE
