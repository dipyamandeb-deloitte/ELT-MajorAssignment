{{ config(materialized='table') }}



select code,month(NAV_DATE) as month,avg(NAV) as average_nav,avg(REPURCHASE_PRICE) as average_repurchase,avg(SALE_PRICE)
as average_sale
from "MAJORASSIGNMENT"."MAJOR"."NAV_HISTORY"
group by CODE,month
